package es.ucm.fdi.iw.model;

public class Acciones {
    
    public String rol;
    public String client;
    public String victim;
    public String option;

}